import {
  Association,
  BelongsToGetAssociationMixin,
  BelongsToSetAssociationMixin,
  BelongsToCreateAssociationMixin,
  CreationOptional,
  DataTypes,
  InferCreationAttributes,
  InferAttributes,
  Model,
  NonAttribute,
  Sequelize
} from 'sequelize'
import type { Post } from './Post'
import type { Tag } from './Tag'

export class PostTag extends Model<
  InferAttributes<PostTag>,
  InferCreationAttributes<PostTag>
> {
  declare tagId: CreationOptional<number>
  declare createdAt: CreationOptional<Date>
  declare updatedAt: CreationOptional<Date>

  // PostTag belongsTo Post
  declare post: NonAttribute<Post>
  declare getPost: BelongsToGetAssociationMixin<Post>
  declare setPost: BelongsToSetAssociationMixin<Post, number>
  declare createPost: BelongsToCreateAssociationMixin<Post>
  
  // PostTag belongsTo Tag
  declare tag: NonAttribute<Tag>
  declare getTag: BelongsToGetAssociationMixin<Tag>
  declare setTag: BelongsToSetAssociationMixin<Tag, number>
  declare createTag: BelongsToCreateAssociationMixin<Tag>
  
  declare static associations: {
    post: Association<PostTag, Post>,
    tag: Association<PostTag, Tag>
  }

  static initModel(sequelize: Sequelize): typeof PostTag {
    PostTag.init({
      tagId: {
        type: DataTypes.BIGINT,
        primaryKey: true
      },
      createdAt: {
        type: DataTypes.DATE
      },
      updatedAt: {
        type: DataTypes.DATE
      }
    }, {
      sequelize
    })
    
    return PostTag
  }
}
