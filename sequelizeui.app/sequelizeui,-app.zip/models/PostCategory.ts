import {
  Association,
  BelongsToGetAssociationMixin,
  BelongsToSetAssociationMixin,
  BelongsToCreateAssociationMixin,
  CreationOptional,
  DataTypes,
  InferCreationAttributes,
  InferAttributes,
  Model,
  NonAttribute,
  Sequelize
} from 'sequelize'
import type { Category } from './Category'
import type { Post } from './Post'

export class PostCategory extends Model<
  InferAttributes<PostCategory>,
  InferCreationAttributes<PostCategory>
> {
  declare categoryId: CreationOptional<number>
  declare createdAt: CreationOptional<Date>
  declare updatedAt: CreationOptional<Date>

  // PostCategory belongsTo Post
  declare post: NonAttribute<Post>
  declare getPost: BelongsToGetAssociationMixin<Post>
  declare setPost: BelongsToSetAssociationMixin<Post, number>
  declare createPost: BelongsToCreateAssociationMixin<Post>
  
  // PostCategory belongsTo Category
  declare category: NonAttribute<Category>
  declare getCategory: BelongsToGetAssociationMixin<Category>
  declare setCategory: BelongsToSetAssociationMixin<Category, number>
  declare createCategory: BelongsToCreateAssociationMixin<Category>
  
  declare static associations: {
    post: Association<PostCategory, Post>,
    category: Association<PostCategory, Category>
  }

  static initModel(sequelize: Sequelize): typeof PostCategory {
    PostCategory.init({
      categoryId: {
        type: DataTypes.BIGINT,
        primaryKey: true
      },
      createdAt: {
        type: DataTypes.DATE
      },
      updatedAt: {
        type: DataTypes.DATE
      }
    }, {
      sequelize
    })
    
    return PostCategory
  }
}
