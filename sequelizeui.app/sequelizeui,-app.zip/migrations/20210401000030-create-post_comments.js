const DataTypes = require('sequelize').DataTypes

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('post_comments', {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        field: 'id',
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      title: {
        type: DataTypes.STRING(75),
        field: 'title',
        allowNull: false
      },
      published: {
        type: DataTypes.BOOLEAN,
        field: 'published',
        allowNull: false
      },
      publishedAt: {
        type: DataTypes.DATE,
        field: 'published_at'
      },
      content: {
        type: DataTypes.TEXT,
        field: 'content'
      },
      createdAt: {
        type: DataTypes.DATE,
        field: 'created_at'
      },
      updatedAt: {
        type: DataTypes.DATE,
        field: 'updated_at'
      },
      postId: {
        type: DataTypes.INTEGER.UNSIGNED,
        field: 'post_id'
      },
      parentId: {
        type: DataTypes.INTEGER.UNSIGNED,
        field: 'parent_id'
      },
      postCommentId: {
        type: DataTypes.INTEGER.UNSIGNED,
        field: 'post_comment_id'
      }
    })
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('post_comments');
  },
};