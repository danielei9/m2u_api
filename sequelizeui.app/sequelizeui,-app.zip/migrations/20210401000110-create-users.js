const DataTypes = require('sequelize').DataTypes

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('users', {
      id: {
        type: DataTypes.INTEGER.UNSIGNED,
        field: 'id',
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
      },
      firstName: {
        type: DataTypes.STRING(50),
        field: 'first_name'
      },
      middleName: {
        type: DataTypes.STRING(50),
        field: 'middle_name'
      },
      lastName: {
        type: DataTypes.STRING(50),
        field: 'last_name'
      },
      mobile: {
        type: DataTypes.STRING(15),
        field: 'mobile'
      },
      email: {
        type: DataTypes.STRING(50),
        field: 'email'
      },
      passwordHash: {
        type: DataTypes.STRING(32),
        field: 'password_hash'
      },
      registeredAt: {
        type: DataTypes.DATE,
        field: 'registered_at',
        allowNull: false,
        defaultValue: DataTypes.NOW
      },
      lastLogin: {
        type: DataTypes.DATE,
        field: 'last_login'
      },
      intro: {
        type: DataTypes.TEXT,
        field: 'intro'
      },
      profile: {
        type: DataTypes.TEXT,
        field: 'profile'
      },
      createdAt: {
        type: DataTypes.DATE,
        field: 'created_at'
      },
      updatedAt: {
        type: DataTypes.DATE,
        field: 'updated_at'
      }
    })
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('users');
  },
};