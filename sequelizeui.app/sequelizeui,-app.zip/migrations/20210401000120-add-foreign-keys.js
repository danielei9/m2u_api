const DataTypes = require('sequelize').DataTypes

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.addConstraint('categories', {
      fields: ['parent_id'],
      type: 'foreign key',
      name: 'categories_parent_id_fkey',
      references: {
        table: 'categories',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('categories', {
      fields: ['category_id'],
      type: 'foreign key',
      name: 'categories_category_id_fkey',
      references: {
        table: 'categories',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('posts', {
      fields: ['author_id'],
      type: 'foreign key',
      name: 'posts_author_id_fkey',
      references: {
        table: 'users',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('posts', {
      fields: ['parent_id'],
      type: 'foreign key',
      name: 'posts_parent_id_fkey',
      references: {
        table: 'posts',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('posts', {
      fields: ['post_id'],
      type: 'foreign key',
      name: 'posts_post_id_fkey',
      references: {
        table: 'posts',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('post_categories', {
      fields: ['category_id'],
      type: 'foreign key',
      name: 'post_categories_category_id_fkey',
      references: {
        table: 'categories',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('post_categories', {
      fields: ['post_id'],
      type: 'foreign key',
      name: 'post_categories_post_id_fkey',
      references: {
        table: 'posts',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('post_comments', {
      fields: ['post_id'],
      type: 'foreign key',
      name: 'post_comments_post_id_fkey',
      references: {
        table: 'posts',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('post_comments', {
      fields: ['parent_id'],
      type: 'foreign key',
      name: 'post_comments_parent_id_fkey',
      references: {
        table: 'post_comments',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('post_comments', {
      fields: ['post_comment_id'],
      type: 'foreign key',
      name: 'post_comments_post_comment_id_fkey',
      references: {
        table: 'post_comments',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('post_metas', {
      fields: ['post_id'],
      type: 'foreign key',
      name: 'post_metas_post_id_fkey',
      references: {
        table: 'posts',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('post_tags', {
      fields: ['tag_id'],
      type: 'foreign key',
      name: 'post_tags_tag_id_fkey',
      references: {
        table: 'tags',
        field: 'id'
      }
    })
    
    await queryInterface.addConstraint('post_tags', {
      fields: ['post_id'],
      type: 'foreign key',
      name: 'post_tags_post_id_fkey',
      references: {
        table: 'posts',
        field: 'id'
      }
    })
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.removeConstraint('categories', 'categories_parent_id_fkey')
    await queryInterface.removeConstraint('categories', 'categories_category_id_fkey')
    await queryInterface.removeConstraint('posts', 'posts_author_id_fkey')
    await queryInterface.removeConstraint('posts', 'posts_parent_id_fkey')
    await queryInterface.removeConstraint('posts', 'posts_post_id_fkey')
    await queryInterface.removeConstraint('post_categories', 'post_categories_category_id_fkey')
    await queryInterface.removeConstraint('post_categories', 'post_categories_post_id_fkey')
    await queryInterface.removeConstraint('post_comments', 'post_comments_post_id_fkey')
    await queryInterface.removeConstraint('post_comments', 'post_comments_parent_id_fkey')
    await queryInterface.removeConstraint('post_comments', 'post_comments_post_comment_id_fkey')
    await queryInterface.removeConstraint('post_metas', 'post_metas_post_id_fkey')
    await queryInterface.removeConstraint('post_tags', 'post_tags_tag_id_fkey')
    await queryInterface.removeConstraint('post_tags', 'post_tags_post_id_fkey')
  }
};