# blog
This project was generated with [Sequelize UI](https://github.com/tomjschuster/sequelize-ui). The project is a simple [Node.js](https://nodejs.dev/) server with [Sequelize ORM](https://sequelize.org/).

Be sure to test all code for correctness and to test database migrations in a test environment before deploying to production.

## Schema
The Sequelize schema for this project was derived from the Blog sample database.

The Blog sample database is a schema for blogging website with users, posts, comments, tags and categories.

The schema was created by Bhagwat Singh Chouhan with Tutorials24x7 under the [MIT License](https://opensource.org/licenses/MIT) and is available at <https://github.com/tutorials24x7/blog-database-mysql>.

The schema was converted to TypeScript for Sequelize UI by Tom Schuster and is available at <https://github.com/tomjschuster/sequelize-ui-ts/blob/main/src/api/schema/examples/sakila.ts>.

## Running Project

### Prerequesites
- [Node.js](https://nodejs.dev/)
- [PostgreSQL](https://www.postgresql.org/)

### Setup
1. Install dependencies: `npm install`
2. Setup database: `npm run db:up`

### Run
- Local development: `npm run dev`
- Production build: `npm run build && npm start`

## Bug Reports
Please report any bugs with generated code at [Sequelize UI Issues](https://github.com/tomjschuster/sequelize-ui/issues).
